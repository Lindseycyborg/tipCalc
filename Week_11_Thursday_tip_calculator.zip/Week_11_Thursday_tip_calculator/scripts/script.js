document.querySelectorAll("li").forEach(function(el){
    el.addEventListener('click', function(){
        // Get the value from the "inputDollarAmount" input field
        var billAmount = Number(document.getElementById("inputDollarAmount").value);
        console.log (billAmount);
        //get the tip $ amount from the drop down option selected
        var selectedTipAmount = document.querySelector('.dropdown-toggle').innerText = el.textContent;
        // convert the selected tip % to a decimal and divide by 100
        var decimal = Number(selectedTipAmount/100);
        console.log (decimal);
        // get tip amount by multiplying the decimal by the bill amount
        var tipAmountTotal= Number(decimal*billAmount);
        console.log(tipAmountTotal)
        // display tip amount in the "tipAmount" input field
        document.getElementById("tipAmount").innerHTML = tipAmountTotal;
        // add the "tipAmount" to the "billAmount"
        var totalAmountOfBill = tipAmountTotal+billAmount
        // display the amount in the "totalAmount" input field
        document.getElementById("totalAmount").innerHTML = totalAmountOfBill;
       

    });

});